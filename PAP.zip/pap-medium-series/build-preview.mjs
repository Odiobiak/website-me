// Builds preview.html from the three parts, for reading and for copying into Medium. Run: node build-preview.mjs
import { readFileSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const { marked } = require("/Users/Odiche.Obiakarije/.npm/_npx/668c188756b835f3/node_modules/marked/lib/marked.cjs");

const parts = ["part-1-why.md", "part-2-how.md", "part-3-findings.md"];
const body = parts.map((f, i) => `<article id="part-${i + 1}">${marked.parse(readFileSync(new URL(f, import.meta.url), "utf8"))}</article>`).join("\n<hr class=\"part\">\n");
const nav = parts.map((_, i) => `<a href="#part-${i + 1}">Part ${i + 1}</a>`).join("");

writeFileSync(new URL("preview.html", import.meta.url), `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Personal Agent Series</title>
<style>
:root{--bg:#fff;--fg:#242424;--muted:#6b6b6b;--rule:#e6e6e6;--code:#f2f2f2;--link:#1a8917}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#121212;--fg:#e8e8e8;--muted:#a0a0a0;--rule:#333;--code:#1e1e1e;--link:#5fd068}}
:root[data-theme="dark"]{--bg:#121212;--fg:#e8e8e8;--muted:#a0a0a0;--rule:#333;--code:#1e1e1e;--link:#5fd068}
body{margin:0;background:var(--bg);color:var(--fg);font:20px/1.6 Georgia,"Times New Roman",serif}
nav{flex-wrap:wrap;position:sticky;top:0;background:var(--bg);border-bottom:1px solid var(--rule);padding:10px 16px;display:flex;gap:18px;font:14px system-ui,sans-serif;z-index:1}
nav a{color:var(--fg);text-decoration:none}
article{max-width:700px;margin:0 auto;padding:32px 16px;overflow-wrap:anywhere}
h1,h2,h3{font-family:system-ui,-apple-system,sans-serif;line-height:1.25}
h1{font-size:40px;margin:.4em 0 .2em} h1+h2{font-weight:400;color:var(--muted);font-size:22px;margin-top:0}
h2{font-size:26px;margin-top:1.8em} h3{font-size:21px;margin-top:1.4em}
a{color:var(--link)} img{max-width:100%;height:auto;border:1px solid var(--rule);border-radius:4px;display:block;margin:24px auto 6px}
p>img+em{display:block;text-align:center;color:var(--muted);font-size:15px;font-family:system-ui,sans-serif;line-height:1.4}
pre{background:var(--code);padding:14px;overflow-x:auto;font-size:13.5px;line-height:1.45;border-radius:4px}
code{font-family:Menlo,Consolas,monospace;font-size:.85em;background:var(--code);padding:1px 4px;border-radius:3px} pre code{background:none;padding:0}
hr{border:0;border-top:1px solid var(--rule);margin:32px 0} hr.part{border-top:6px double var(--rule);margin:48px auto;max-width:700px}
blockquote{border-left:3px solid var(--fg);margin:0;padding-left:18px;font-style:italic}
table{border-collapse:collapse;font-size:16px} td,th{border:1px solid var(--rule);padding:6px}
</style></head><body><nav><strong>Personal agent series</strong>${nav}</nav>
${body}
</body></html>`);
console.log("preview.html written");
