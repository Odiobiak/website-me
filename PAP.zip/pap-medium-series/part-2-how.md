# How I Built a Personal AI Assistant That Proves Who It Is

## Part 2 of 3: the architecture, the handshake, the impostor tests, customer consent, and a direct-to-tools route over MCP

*Series: Building for Personal AI Agents. [Part 1: why](#) · Part 2 (this one): how · Part 3: what I tested, what broke, and what I'd tell a business.*

---

In Part 1, I argued that companies need a front door for personal AI assistants that identify themselves, and introduced the Personal Agent Protocol (PAP). This part is the build.

## The three pieces

```
Grace (a person)
   │  "Get me a car insurance quote"
   ▼
Grace's assistant ─────────────────────────────┐
  (GPT-4.1, its own signing key,               │  PAP: discovery, signed identity,
   knows Grace's household)                    │  key-bound tokens, consent
                                               ▼
                                 Harbor Lane's PAP gateway
                                  (checks the assistant,
                                   issues sessions, signs
                                   customers in)
                                               │
                     ┌─────────────────────────┴──────────────────────┐
                     ▼                                                ▼
         Route 1: a conversation                        Route 2: tools over MCP
         with Harbor Lane's AI agent                    (the same agent's quote tools,
         (NiCE Cognigy, REST endpoint)                   called directly)
                     │                                                │
                     └──────────────► the same quote rules ◄──────────┘
                                     (validation, what's never
                                      collected, when a human
                                      advisor takes over)
```

**Grace's assistant** is a small web app with a server. Its "brain" is GPT-4.1 with a handful of tools: talk to the company, sign in to the company, read Grace's account, ask for a person, finish. It holds a private signing key and publishes the public half at a URL (its `agent.json` and `jwks.json`). That URL is its identity.

**Harbor Lane's gateway** is the company's front door: a few static files and a handful of serverless endpoints. It checks who's knocking, issues sessions, handles customer sign-in, and passes approved traffic on to the insurer's AI agent. State (seen tokens, sessions, sign-in requests) lives in a small Redis store, so replay protection holds across servers.

**The insurer's AI agent** is an auto quote agent built in NiCE Cognigy. It's the same agent a person can chat with on Harbor Lane's home page. Assistants reach it through the gateway, never directly.

I also built a **side-by-side page** to watch it all happen: Grace and her assistant on the left, her assistant and the company on the right, with every request one click away.

![The side-by-side page. The left pane shows Grace's chat with her assistant. The right pane shows the session, the conversation with the insurer's agent and the answers saved for the quote.](images/02-side-by-side.jpg)
*Left: Grace and her assistant. Right: what the assistant and the insurer said, the verified session, and what's been saved for the quote.*

## Step 1: find the front door

The assistant starts by reading the company's signpost. Harbor Lane's says: we speak PAP 0.2, here's our issuer, customers can sign in with a device code and grant two scopes, and here are three ways in.

```json
{
  "protocol_version": "0.2",
  "organization": { "name": "Harbor Lane Insurance", "domain": "harbor-lane.example" },
  "auth": {
    "issuer": "https://harbor-lane.example",
    "device": { "scopes": ["policies", "contact"] },
    "custom_scopes": {
      "policies": "See your Harbor Lane policies",
      "contact": "See the name, address, phone and email on your account"
    }
  },
  "agent": {
    "protocols": [{ "type": "poppy", "endpoint": "https://harbor-lane.example/api/pap/conversations" }]
  },
  "apis": [
    { "type": "openapi", "url": "https://harbor-lane.example/openapi.json",
      "description": "Your account: your policies and contact details. Needs the customer to sign in." },
    { "type": "mcp", "url": "https://harbor-lane.example/api/pap/mcp",
      "description": "Get an auto quote by calling our quote tools directly. No account needed." }
  ]
}
```

The assistant doesn't trust this blindly. It checks that the file's domain and issuer match the site it actually fetched from, that it's HTTPS, and that the version is one it speaks. Then it reads the standard OAuth metadata to learn where to ask for a session.

## Step 2: prove who you are

This is the heart of it. The assistant sends one request to the company's token endpoint containing three signed things:

- **A client assertion**: "I am the assistant at `https://graces-assistant.example/agent/agent.json`", signed with its key, valid for 60 seconds.
- **A user assertion**: "I'm acting for `user-wbtym9vn1c`", an opaque id. The company never learns Grace's name at this stage.
- **A DPoP proof**: a signature over this exact request (method, URL, time) made with a *separate* key, one per user.

The company fetches the assistant's public key from its published URL, checks both signatures and their short lifetimes, refuses anything it has seen before (no replays), and checks the assistant is on its trusted list. Then it hands back a session token that is **bound to the DPoP key**. Every later request must carry a fresh proof made with that key.

![The handshake card: six numbered calls, from reading poppy.json and the OAuth metadata, to proving identity at the token endpoint, the company checking the assistant's agent.json and jwks.json, and opening the conversation.](images/03-handshake.jpg)
*The handshake as the prototype shows it: each call, in order, with plain-language notes. Signatures and tokens are cut before anything reaches the page.*

Then the assistant opens a conversation and introduces itself. On the company's side, the AI agent is told it's talking to a verified personal agent acting for a customer, not to the customer.

## Step 3: try to break it

A front door is only as good as the lock. So the page has a **Try an impostor** button that runs three real attacks against the gateway:

1. **An assistant the company doesn't know.** Validly signed, but not on the trusted list. Refused: `invalid_client`.
2. **An impostor claiming to be Grace's assistant.** Same name, same client id, but it doesn't have the real key. The company fetches the genuine public key, the signature doesn't match. Refused.
3. **A stolen session token.** Someone copies a real, valid token and uses it from their own machine. They can only make DPoP proofs with *their* key, and the token is bound to Grace's assistant's key. Refused: `invalid_dpop_proof`.

![Three impostor test cards, each marked Refused: an unknown agent (invalid_client), an agent pretending to be Grace's assistant (invalid signature), and a stolen session token (invalid_dpop_proof, bound to a different key).](images/04-impostors-refused.jpg)
*All three are refused at the gateway, before the insurer's AI agent sees a word.*

The third one is the one I'd point a security team at. Bearer tokens, the kind most APIs use, work for whoever holds them. A key-bound token doesn't.

## Step 4: let the customer decide

A quote needs no account. But when Grace asks, "What policies do I already have with Harbor Lane?", that's private, and her assistant has no right to it yet.

So the assistant asks for a sign-in. Harbor Lane returns a short code. The assistant shows Grace a link and the code. Grace opens Harbor Lane's own site, signs in there (her assistant never sees her password), and sees exactly who is asking and for what. She can untick anything before approving.

![Harbor Lane's approval page: "Connect Grace's assistant?", the code to check, a tick box for "See your Harbor Lane policies", and Approve and Decline buttons.](images/05-customer-consent.jpg)
*Grace approves on the insurer's site, not inside the assistant. Opening the page approves nothing.*

While Grace decides, the assistant quietly checks back every few seconds. It makes no AI model calls while it waits. Once she approves, its session is upgraded to signed in with only the scope she granted, plus a 30-day account token it can use to stay connected. Either side can disconnect: Grace from her account page, or the assistant by revoking its token.

![The session panel after approval: verified agent, the anonymous user id the company sees, signed in to Grace's account, can read her policies only, session and account token expiry, and a Disconnect button.](images/06-signed-in-session.jpg)
*After Grace approves: signed in, policies only, and a Disconnect button. The company still only knows Grace by an anonymous id at the protocol level.*

## Step 5: a second route, straight to the tools

A conversation between two AIs works, but it's a strange way for software to exchange 46 answers. So I built a second route. Instead of chatting with Harbor Lane's agent, the assistant calls the agent's **quote tools directly over MCP**: structured arguments in, and the next question back as data.

The same PAP rules apply. The assistant gets a token issued for the MCP server's URL only (a token for the conversation route won't work there, and vice versa), and every call carries a key-bound proof. Behind the gateway, those MCP calls run through the **same tool logic and the same quote rules** as the conversation route.

![The MCP route: the right pane shows the assistant calling collect_quote_data with structured arguments, and Harbor Lane's tools replying with the next question as data.](images/07-mcp-route.jpg)
*On the MCP route there's no chat on the company side: tool calls out, the next question back as data.*

One detail I liked: the company's gateway decides which quote a call belongs to, from the verified assistant and user. The assistant can't pick, or guess, someone else's quote id.

## How close to the spec?

I checked the build against the PAP 0.2 spec section by section, wrote an automated test suite organised by spec section, and ran the protocol's own conformance validator against the deployed gateway. The final validator run had **58 checks pass and 0 fail**. The only skips were for optional features I hadn't built (streaming, nonces) and routes that validator run didn't cover.

The first validator run wasn't clean, which was the useful part. It caught a token endpoint that accepted a browser-type assertion where a session assertion was required. One line to fix, but not something I'd have spotted by reading my own code.

## A note on the screenshots

The screenshots in this series come from a local test run. Everything on the company's side (the gateway, the checks, and the insurer's AI agent in Cognigy) was real. To make the run repeatable for screenshots, the assistant's own replies were scripted. The numbers I quote (exchanges, saved answers, timings) come from live runs with GPT-4.1 as the assistant.

In **Part 3**: what happened when two AIs met, what broke, what each route costs, and what I'd tell a business that wants to be ready.

---

*Harbor Lane Insurance and Grace Banks are invented. This is a prototype, not a product, and the views are my own.*

**Tags:** AI Agents, OAuth, API Security, Model Context Protocol, Software Architecture
