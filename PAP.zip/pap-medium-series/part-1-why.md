# Your Customers' AI Assistants Are Already at Your Front Door

## Part 1 of 3: Why companies need a way to recognise and welcome personal AI agents, and what the Personal Agent Protocol proposes

*Series: Building for Personal AI Agents. Part 1 (this one): why. Part 2: how I built a working prototype. Part 3: what I tested, what broke, and what I'd tell a business.*

![The side-by-side prototype: on the left, Grace talks to her personal AI assistant. On the right, her assistant talks to the insurer's AI agent.](images/02-side-by-side.jpg)
*The prototype I built: Grace and her assistant on the left, her assistant and a (fictional) insurer on the right.*

---

Picture a customer who never opens your website.

She tells her AI assistant, "Get me a car insurance quote." The assistant already knows her address, her car and who drives it. It goes to your site, works through your quote, and comes back with a price. She answers two questions it couldn't know. That's it.

This isn't far off. Personal AI assistants that browse, fill in forms and make calls for people are already here, and companies are starting to notice them in their own data: sessions that move faster than any person, answers that are perfectly consistent, traffic that looks a little too tidy.

Most of these assistants don't say they're AI. To your website, they look like an unusually fast customer. To your phone line, sometimes, they sound like one.

I work as a Forward Deployed Engineer building conversational AI agents for large enterprises. When this question came up, I wanted to know what it actually takes to give these assistants a proper front door, so I built one. This series is what I learned.

## Two kinds of assistant

It helps to split the traffic in two.

**Undisclosed assistants** pose as the customer. They click through your web form, type into your chat, or call your contact center. You can try to detect them (timing, phrasing, how consistent they are), but it's an arms race. Every detection signal is a hint for the next version of the assistant.

**Disclosed assistants** say what they are. "I'm Grace's assistant, and I'm acting for her." If a company could check that claim, and decide what that assistant is allowed to do, most of the hard problems get easier:

- You know who you're talking to, and on whose behalf.
- You can give the assistant a route that suits it, like structured data instead of a web page built for eyes.
- You can ask the actual customer for consent before anything sensitive is shared.
- You keep your own business rules in charge, whichever route the assistant takes.

Blocking every assistant isn't realistic, and it punishes the honest ones. The better strategy is layered: welcome the assistants that identify themselves, keep detecting and rate-limiting the ones that don't, and send anything suspicious to fraud checks or a person.

## What the Personal Agent Protocol proposes

The Personal Agent Protocol (PAP) is an early, open attempt at that front door. I worked against draft 0.2 of the spec. It doesn't invent much. It combines standards most companies already use (OAuth, JSON Web Tokens, DPoP proof-of-possession, OpenAPI and MCP) into a small set of agreements:

1. **A signpost.** A public file on the company's site, `/.well-known/poppy.json`, that says "we talk to personal agents, here is how, and here is what we offer".
2. **Proof of identity.** The assistant signs two short statements: who it is (a public URL that publishes its key) and who it's acting for (an anonymous user id, never the customer's name). The company checks both signatures and whether it trusts that assistant.
3. **Tokens that can't be stolen and reused.** The session the company hands back only works together with a key the assistant holds. Copy the token to another machine and it's worthless.
4. **Customer sign-in without sharing a password.** For private data, the customer approves on the company's own site with a short code, and chooses exactly what the assistant may see.
5. **Routes.** The company lists how an assistant can work with it: a conversation with the company's own AI agent, plain APIs, or tools over MCP (the Model Context Protocol).

Importantly, PAP isn't a new channel. A person can still fill in your form, chat or call. PAP is a door for the assistants that ask to come in properly.

## Why I think this matters now

Three reasons.

**The traffic isn't waiting for the standard.** PAP has no version 1 yet, and not every major assistant vendor has committed to it. Customers are using assistants anyway. Companies that wait for the dust to settle will meet that traffic with whatever their web forms and IVR menus happen to do today.

**Your AI agent was built for people.** Most companies that have deployed conversational AI tuned it for human customers: warmth, rapport, "see the screen", "say 'representative' to talk to someone". As you'll see in Part 3, a lot of that is wrong, or just odd, when the other party is software.

**Trust is the product.** In regulated industries like insurance, banking and healthcare, "who said this, on whose behalf, and did the customer agree?" isn't a nice-to-have. It's the whole question. An assistant that can prove who it is and who it works for is something a compliance team can reason about. An assistant pretending to be a customer isn't.

## What I built

To find out what this looks like in practice, I built both sides and ran a complete auto insurance quote through it:

- **Grace's assistant**: a personal AI assistant for Grace Banks, an invented customer. It knows her household and goes to get a quote when she asks.
- **Harbor Lane Insurance**: a fictional insurer with a website, customer accounts, and a PAP front door.
- **The insurer's own AI agent**: an auto quote agent built in NiCE Cognigy, the same kind of agent a person would chat with or call.

![Harbor Lane Insurance's home page, with a section welcoming personal AI assistants and pointing them to /.well-known/poppy.json](images/01-harbor-lane-home.jpg)
*Harbor Lane, the fictional insurer. Its home page tells people, and assistants, how assistants are welcome.*

Grace typed one sentence. Her assistant found the insurer, proved who it was, ran the full quote (about 20 exchanges and 46 saved answers in the first full run), and stopped to ask Grace only what it couldn't know. Before confirming, it showed her the summary and waited for her yes.

In **Part 2**, I'll walk through how it's built: the handshake step by step, how the company checks the assistant, the impostor tests, customer consent, and a second route where the assistant skips the conversation and calls the insurer's tools directly.

In **Part 3**, I'll cover what I tested, what broke (both AIs made things up), the trade-offs between routes, and what I'd tell any business getting ready for this.

---

*Harbor Lane Insurance and Grace Banks are invented. This is a prototype, not a product, and the views are my own.*

**Tags:** Artificial Intelligence, AI Agents, Customer Experience, Conversational AI, Security
