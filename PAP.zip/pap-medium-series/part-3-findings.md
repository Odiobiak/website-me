# When Two AIs Meet: What Broke, What Worked, and What I'd Tell Your Business

## Part 3 of 3: the test results, the surprises, the pros and cons, and a short checklist for companies

*Series: Building for Personal AI Agents. [Part 1: why](#) · [Part 2: how](#) · Part 3 (this one): what I tested, what broke, and what I'd tell a business.*

---

In Part 2, I walked through the build: a personal AI assistant for Grace, a fictional insurer called Harbor Lane with a Personal Agent Protocol (PAP) front door, and the insurer's own AI agent behind it. This part is about what happened when I ran it.

## What I tested

- **Full quote, conversation route.** Grace typed one sentence and her assistant did the rest. It reached a rate in about 20 exchanges, with 46 answers saved, and asked Grace only what it couldn't know.
- **Identity and replay.** Signed assertions with short lifetimes were accepted; reused assertions and proofs were refused.
- **Impostors.** An unknown agent, a forged identity and a stolen token were all refused before the AI agent saw anything.
- **Customer consent.** Device sign-in, partial approval, decline, expiry, and disconnect from either side. The assistant read only what Grace granted, and a disconnect dropped it back to signed out.
- **Tools route (MCP).** The same quote over the insurer's tools instead of a conversation worked end to end, at 0.3 to 2.7 seconds per call.
- **Spec conformance.** The protocol's own validator against the deployed gateway: 58 passed, 0 failed (after one fix).
- **Automated tests.** About 40 tests across both sides, organised by spec section, run on every change.

Each exchange on the conversation route took about 3 to 5 seconds. The protocol overhead (discovery plus the handshake) was a few hundred milliseconds, once per session.

## What surprised me

### 1. The protocol is small. The work is behind it.

The front door is a few static files and a handful of endpoints. I had the handshake working in days. The hard questions turned out to be business questions:

- Which routes do you open: a conversation, APIs, tools, all three?
- Which assistants do you trust, and how does one get on your list?
- What can an assistant do signed out, and what needs the customer's approval?
- Who owns this inside the company: digital, security, fraud, or the contact center?

### 2. Your AI agent was built for people, and it shows

The insurer's agent was tuned for human customers. Put an AI on the other side and some of that tuning misfires:

- When the assistant mentioned "she just got married", the agent congratulated it. Warm with a person, odd with software relaying facts.
- At the end it said "your quote is on your screen". An assistant doesn't have a screen. The rate has to come back as **data**.
- Words like "agent" and "person" are classic triggers for "transfer me to a human". From an AI assistant, they mean something else entirely.
- It offered a document upload screen, which an assistant can't use.

None of this is hard to fix (a line in the agent's instructions, a rate returned in the message's data). But you only find it by running a real assistant against your agent.

### 3. Both AIs made things up, so the rules have to live in code

This was the most important finding.

When it didn't know something, **Grace's assistant guessed**. Asked roughly what the car cost new, it said "about $32,000". Nobody told it that.

**The insurer's agent did it too.** It worked out an annual mileage from a commute ("about 6,240 miles a year", which is 12 miles × 2 × 5 days × 52 weeks) and mentioned coverage limits nobody had given.

Better prompts reduced this. They didn't stop it. What actually worked:

- **On the assistant's side**: anything it doesn't know is marked "not known" in its memory, and it asks its user rather than estimating.
- **On the company's side**: every answer passes through one validation gate in code before it's stored. A value that wasn't given is never saved, things the company must never collect are dropped, and the decision about when a human takes over is made by rules, not by the model's mood.

When two language models talk to each other, each will fill gaps with plausible-sounding answers. Without deterministic checks, those guesses become data.

### 4. Asking again costs trust, and money

The assistant described a claim in one message: what happened, when, nobody hurt, not at fault. The agent saved the headline and then asked what happened, who was driving and whether anyone was hurt, one question at a time.

A person shrugs that off. For an assistant, every extra turn is latency and model cost, and it reads as a system that isn't listening. I changed the company side so each question checks whether the last message already answered it, and a few plain phrases ("nobody was hurt", "not her fault") are recognised in code. The claim went from four exchanges to one plus a follow-up.

### 5. Customers can sign in without sharing a password

The device sign-in flow felt right. Grace approves on the insurer's own site, sees exactly who is asking and for what, unticks what she doesn't want to share, and can disconnect later. Her assistant never sees her password. For a regulated business, that's a consent record you can actually point to.

### 6. Direct tool calls aren't free

The MCP route cut the chatter: no small talk, no re-phrasing, just structured answers and the next question back. But the tool definitions are about **6,000 tokens**, and the assistant's model carries them on every call. Whether that's cheaper than a conversation depends on how long the quote is. The prototype has a scorecard that shows both routes side by side (time, calls, model calls, tokens, estimated cost), because "it depends" deserves numbers.

### 7. Keep the same rules on every route

This is the one I'd underline. Whether the assistant chats or calls tools, **the same code decides what's asked, what's accepted, and when a human advisor takes over**. If an assistant can go straight to your tools, your conversation layer is skipped, but your business rules must not be. That's the argument for one orchestration layer behind every route, rather than a separate set of rules per channel.

## Pros and cons

**What's good about the PAP approach**

- **Built on standards companies already run.** OAuth, JWT, DPoP, OpenAPI, MCP. Security teams can review it with tools they know.
- **Identity you can verify.** You know which assistant is calling and that it's acting for a user, without learning who that user is until they choose to sign in.
- **Stolen tokens don't work.** Key-bound sessions remove a whole class of attack.
- **Consent is explicit.** The customer approves on your site, per scope, and can revoke it.
- **Routes fit the caller.** Assistants can use data-first routes instead of screen-scraping pages built for people.
- **It doesn't replace anything.** Forms, chat and phone carry on for people.

**What's hard, or not there yet**

- **Early.** No version 1 at the time of writing, and not every major assistant vendor has committed. Undisclosed assistants won't use it.
- **Trust lists are a business decision.** The protocol tells you who an assistant is, not whether you should trust it. Someone has to own that list.
- **Your agent needs adapting.** Rapport, "on your screen", exit words, upload screens: all tuned for people.
- **Hallucination on both sides.** Two models talking can invent facts together. You need validation in code, not just good prompts.
- **Liability questions.** Who accepted the disclosure? Who attested the application facts, the customer or their assistant? That's for legal and compliance, and it isn't settled.
- **Cost trade-offs.** Tool routes are efficient per turn but carry large tool schemas; conversations are chattier but lighter per call.
- **Platform maturity.** Some of the building blocks I used for the tools route are still labelled experimental by their vendors. Fine for a prototype; not yet for production.

## If you run a digital business today

1. **Assume assistants are already here.** Look for unusually fast, unusually consistent sessions. Flag them in analytics; don't just block them.
2. **Decide your routes and permissions first.** The protocol files are the easy part.
3. **Put your rules in code, not just in prompts.** Validation, what you never collect, and when a person takes over.
4. **Treat what an assistant writes as information, not instructions,** and keep the customer's approval for anything that matters.
5. **Return results as data.** If the answer only appears on a screen, an assistant can't see it.
6. **Test with a real assistant.** Every finding in this post came from running one, not from reading the spec.

## Closing

Building both sides took days, not months. What took longer was unlearning an assumption I didn't know I had: that the customer on the other end of the conversation is a person. Increasingly, it's a person *and* their assistant, and the companies that design for both will be the easy ones to do business with.

If you're thinking about how your business should meet customers' AI assistants, I'd love to compare notes.

---

*Harbor Lane Insurance and Grace Banks are invented. This is a prototype, not a product, and the views are my own.*

**Tags:** AI Agents, Customer Experience, Generative AI, Conversational AI, Product Strategy
