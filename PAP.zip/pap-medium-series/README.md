# Medium series: Building for Personal AI Agents

Three posts about the Personal Agent Protocol (PAP) prototype, written for Medium. Everything uses the fictional insurer
(Harbor Lane Insurance), the invented customer (Grace Banks) and the public PAP 0.2 spec. No customer names, figures,
people or flows.

| Part | File | Title | About |
| --- | --- | --- | --- |
| 1 | `part-1-why.md` | Your Customers' AI Assistants Are Already at Your Front Door | Why it's needed, what PAP is, the prototype at a glance (~6 min) |
| 2 | `part-2-how.md` | How I Built a Personal AI Assistant That Proves Who It Is | Architecture, handshake, impostor tests, consent, the MCP route, spec conformance (~8 min) |
| 3 | `part-3-findings.md` | When Two AIs Meet: What Broke, What Worked, and What I'd Tell Your Business | What was tested, seven findings, pros and cons, a checklist (~8 min) |

`preview.html` shows all three with the images, ready to copy from. Rebuild it after editing a part:
`node build-preview.mjs`.

## Images

All in `images/`, captured on a local run of the prototype against Harbor Lane only (localhost addresses are visible in
a few; that's fine for a prototype, or crop them).

| File | Used in | Shows |
| --- | --- | --- |
| `02-side-by-side.jpg` | Part 1 cover, Part 2 | The side-by-side page: Grace and her assistant, the assistant and the insurer |
| `01-harbor-lane-home.jpg` | Part 1 | The fictional insurer's home page, welcoming assistants |
| `03-handshake.jpg` | Part 2 | The six handshake calls |
| `04-impostors-refused.jpg` | Part 2 | Three impostor attempts, all refused |
| `05-customer-consent.jpg` | Part 2 | Grace approving on the insurer's site |
| `06-signed-in-session.jpg` | Part 2 | The session after approval: policies only, Disconnect |
| `07-mcp-route.jpg` | Part 2 | The tools route over MCP |

**Honesty note:** on that run the assistant's replies were scripted (no OpenAI key on this machine), while the company
side (gateway, checks, the Cognigy agent) was real. Part 2 says so. The page still shows its "Live (GPT-4.1)" menu in
some shots. The numbers in the posts (20 exchanges, 46 answers, 3 to 5 s, 0.3 to 2.7 s per MCP call, ~6,000 tokens,
58 checks passed) come from live runs and the validator, per `PERSONAL_AGENTS.md`.

## Posting on Medium

1. Paste the text from `preview.html` (opened in a browser) into a new story. Medium keeps headings, bold, lists, links
   and code blocks. Upload each image where its placeholder sits, and paste the caption under it.
2. Medium has no tables. The posts use lists instead.
3. Put them in a Medium **series** or publish as three stories a few days apart, then edit Parts 2 and 3 to link the
   earlier parts (the `[Part 1: why](#)` links are placeholders).
4. Tags: up to five per story; each part ends with suggested ones.
5. Cover image: `02-side-by-side.jpg` for Parts 1 and 2; for Part 3, `04-impostors-refused.jpg` or the side-by-side
   again.

## Before you post (please read)

- **Get an OK from NiCE marketing or comms.** The posts name NiCE Cognigy and describe work done in your role.
- **The work was started for a customer engagement.** The posts keep the customer out entirely, but the prototype began
  there and its code repos sit on your personal GitHub. Confirm you're free to describe it, and to link the repos
  publicly, before Part 2 goes up.
- **Don't link the hosted demos** unless they're meant to be public (they're password protected or private today).
- **Leave out the internal security findings** (they aren't in the posts; keep it that way in comments).
- **PAP vendor claims:** the posts only say the spec is early and not every major vendor has committed. Don't add
  names of vendors or companies from internal calls.

## LinkedIn teaser (for Part 1)

> Your customers' AI assistants are already filling in your forms. Most of them don't say so.
>
> So I built the other version: a personal AI assistant that tells a company exactly who it is, and a company that can
> check. Both sides, end to end, over the Personal Agent Protocol (PAP).
>
> Grace (an invented customer) typed one sentence. Her assistant proved who it was, ran a full auto quote with a
> fictional insurer's AI agent, and asked her only what it couldn't know. Three impostors tried to get in. None did.
>
> I'm writing it up as a three-part series. Part 1 is why this matters: [link]
>
> If you're thinking about how your business should meet customers' AI assistants, I'd love to compare notes.
>
> #AIagents #CustomerExperience #ConversationalAI #AgenticAI

The older single-post drafts are in `../personal-agent-prototype-post.md`.
