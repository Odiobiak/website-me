# Drafts: the personal agent prototype

Two versions: a short LinkedIn post, and a longer Medium article it can link to. Both use only the fictional insurer
(Harbor Lane), the invented customer (Grace Banks) and the public Personal Agent Protocol spec. Check the notes at the
bottom before posting.

---

## LinkedIn post

Your customers' AI assistants are already filling in your forms. Most of them don't say so.

So I built the other version: a personal AI assistant that tells a company exactly who it is, and a company that can
check.

The setup:
- An AI assistant working for Grace, an invented customer
- Harbor Lane, a fictional insurer
- The insurer's own AI agent, built in NiCE Cognigy
- The Personal Agent Protocol (PAP) in between: a signpost file, signed proof of identity, and tokens tied to the
  assistant's key

One side-by-side screen shows both conversations: Grace and her assistant on the left, her assistant and the company on
the right.

What happened: Grace typed one sentence. Her assistant ran the whole auto quote, about 20 exchanges and 46 answers,
and stopped to ask her only what it couldn't know.

What surprised me:
1. The protocol is small. The real work is everything behind it: which routes you open, and to whom.
2. Our agent was built for people. It congratulated the assistant on "her" wedding, and told it the rate was "on your
   screen". Assistants don't have screens.
3. Both AIs made things up when they were unsure. The fix wasn't a better prompt: the checks had to live in code.
4. Letting the assistant call the company's tools directly (MCP) cut the chatter, but the tool list alone cost about
   6,000 tokens on every call.

I wrote up the build and the findings here: [link]

If you're thinking about how your business should meet customers' AI assistants, I'd love to compare notes.

#AIagents #ConversationalAI #CustomerExperience #AgenticAI

---

## Medium article

# I built an AI assistant that talks to an insurer's AI agent. Here's what broke.

Your customers' AI assistants are already showing up on your website. They fill in quote forms, answer chat questions
and sometimes call your phone line. Most of them don't say they're AI. They look like an unusually fast, unusually
consistent customer.

A company has two options. It can try to block them, which turns into an arms race. Or it can give the honest ones a
better way in: a front door where an assistant says who it is and who it works for, and the company decides what it may
do.

The Personal Agent Protocol (PAP) is an early attempt at that front door. I wanted to know what it takes in practice,
so I built both sides and ran a full auto insurance quote through it.

### What I built

Three parts:

- **Grace's assistant.** A personal AI assistant (GPT-4.1) working for Grace Banks, an invented customer. It knows her
  household: her car, her address, the people who drive. When she asks for a quote, it goes and gets one.
- **Harbor Lane Insurance.** A fictional insurer with a website, customer accounts and a PAP "front door": a few public
  files and endpoints that check who's knocking.
- **The insurer's AI agent.** An auto quote agent built in NiCE Cognigy, the same kind of agent a customer would chat
  with or call.

The demo is one side-by-side screen. On the left, Grace talks to her assistant. On the right, you watch her assistant
talk to the insurer, request by request.

### How an assistant proves who it is

The handshake is simpler than it sounds:

1. **Find the front door.** The assistant reads a small public file on the company's site that says "we talk to
   personal agents, here's how".
2. **Prove who you are.** The assistant sends two signed statements: "I am the assistant at this public address" and
   "I'm acting for this user". The user is an anonymous id, never Grace's name. The company fetches the assistant's
   public key and checks the signatures, and checks the assistant is on its list.
3. **Get a session that only works with your key.** The token the company hands back is bound to a key only the
   assistant holds. Every request carries a fresh proof made with that key.

To make that concrete, the demo has a "Try an impostor" button with three attacks: an assistant the company doesn't
know, one pretending to be Grace's assistant with the wrong key, and a stolen session token used from someone else's
machine. All three are refused before the insurer's agent sees a word.

### The first full run

Grace typed: "Get me a car insurance quote."

Her assistant found the insurer, proved who it was, introduced itself, and answered the agent's questions from what it
knew about her. About 20 exchanges later, 46 answers were saved and the quote reached a rate. It stopped to ask Grace
only what it couldn't know, and before confirming the final quote, it showed her the summary and waited for her yes.

That part worked. The interesting part was everything that didn't.

### What I learned

**1. The protocol is small. The work is behind it.**
The front door is a few files and four endpoints. The hard questions are business ones. Which routes do you open: chat,
direct API calls, both? Which assistants may use them? What can an assistant do signed out, and what needs the
customer's approval?

**2. Your agent was built for people.**
The insurer's agent was tuned for human customers, and it showed:
- When the assistant mentioned "she just got married", the agent congratulated it. Warmth is good with a person, odd
  with a piece of software relaying facts.
- At the end it said "your quote is on your screen". An assistant doesn't have a screen, so the rate has to come back
  as data.
- Words like "agent" and "person" were treated as "transfer me to a human". From an AI assistant, those words mean
  something else.

None of this is hard to fix, but you only find it by running a real assistant against your agent.

**3. Both AIs make things up, so the rules have to live in code.**
When it didn't know something, Grace's assistant guessed (it estimated what her car cost new). The insurer's agent did
too: it worked out an annual mileage from a commute, and suggested coverage limits nobody had mentioned. Prompts
reduced it, but they didn't stop it. What did work: checks in code. A value that wasn't given is never saved, every
answer is validated before it's stored, and the assistant marks what it doesn't know and asks its user.

**4. Asking again costs trust.**
The assistant described a claim in one message. The agent saved the headline and then asked what happened, who was
driving and whether anyone was hurt, one question at a time. A person shrugs that off; for an assistant it means extra
turns and cost. Each question now tells the agent to check whether the last message already answered it.

**5. Customers can sign in without sharing a password.**
For private information ("what policies do I already have?"), the assistant asks Grace to sign in. She approves on the
insurer's own site with a short code, sees exactly what the assistant is asking for, and can untick anything. Her
assistant never sees her password, and either side can disconnect later.

**6. Direct tool calls aren't free.**
I also gave the assistant a second route: instead of chatting, it calls the insurer's quote tools directly over MCP
(Model Context Protocol). No conversation, just structured answers and the next question back as data. Fewer
exchanges, but the tool definitions are about 6,000 tokens, and the assistant's model carries them on every call.
Whether that's cheaper than chat depends on the quote.

**7. Keep the same rules on every route.**
This is the one I'd underline. Whether the assistant chats or calls tools, the same code decides what's asked, what's
accepted, and when a human advisor takes over. If an assistant goes straight to your tools, your conversation layer
can be skipped, but your business rules can't be. That's the case for one orchestration layer behind every route, not a
separate set of rules per channel.

### If you run a digital business today

- **Assume assistants are already here.** Look for unusually fast, unusually consistent sessions. Flag them, don't just
  block them.
- **Decide your routes and permissions first.** The protocol files are the easy part.
- **Put your rules in code, not just in prompts.** Validation, things you must never collect, and handover rules.
- **Treat what an assistant writes as information, not instructions,** and keep the customer's approval for anything
  that matters.
- **Test with a real assistant.** Every finding above came from running one, not from reading the spec.

PAP is early: no version 1 yet, and the big assistant vendors haven't all committed. But the traffic isn't waiting for
the standard. Building both sides took days, and it changed how I think about what "customer" means.

*Harbor Lane Insurance and Grace Banks are invented. This is a prototype, not a product, and the views are my own.*

---

## Before posting

- **Get the OK from NiCE marketing or comms.** Both drafts name NiCE Cognigy and describe work you did in your role.
- **Keep the customer out of it.** No customer name, none of their traffic figures, their flow or their people. The
  drafts use only Harbor Lane and Grace.
- **Leave out the security findings.** They're internal, for example the old open endpoint.
- **Use the hosted demo only if it's meant to be public.** The demo pages and the explainer are private or password
  protected today. For an image, use a screenshot of the side-by-side page on Harbor Lane, with nothing customer-related
  on screen.
- **Check the numbers** if you rerun anything. 20 exchanges and 46 answers come from the first full run, and about 6,000
  tokens is the size of the MCP tool list.
